﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using System.Data;
using System.Data.OleDb;

namespace WebApplication1 {
    public class Global : HttpApplication {
        public static OleDbConnection dbConnection;

        protected void Application_Start(object sender, EventArgs e) {
            // Код, выполняемый при запуске приложения
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            // Подключение к БД
            dbConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=C:/TEMP/authors.accdb;");
            dbConnection.Open();
        }

        protected void Application_End(object sender, EventArgs e) {
            dbConnection.Close();
        }

        protected void Session_Start(object sender, EventArgs e) { 
        }
    }
}