﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Database;
using System.Data;

namespace WebApplication1 {
    public partial class AuthorsParam : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {
            if (!Page.IsPostBack) {
                id.Value = Request["id"];
                if (id.Value != "") {
                    AuthorsDB authors = AuthorsDB.Create(Session);
                    textBoxFio.Text = (String)authors.dt.Select("ID="+id.Value)[0]["FIO"];
                    ButtonNew.Text = "Изменить";
                }
                else {
                    ButtonNew.Text = "Добавить";
                }
            }
        }

        protected void ButtonNew_Click(object sender, EventArgs e) {
            if (!Page.IsValid) {
                throw new Exception("Параметры не введены!");
            }
            AuthorsDB authors = AuthorsDB.Create(Session);
            DataRow dr;
            id.Value = Request["id"];
            if (id.Value == "") {                
                dr = authors.dt.NewRow();
                dr["FIO"] = textBoxFio.Text;
                authors.dt.Rows.Add(dr);
                authors.ad.Update(authors.dt);
                Response.Write("<script>self.close();</script>");
            }
            else {
                dr = authors.dt.Select("ID="+id.Value)[0];
                dr["FIO"] = textBoxFio.Text;
                authors.ad.Update(authors.dt);
                Response.Redirect("~/Authors");
            }
        }
    }
}