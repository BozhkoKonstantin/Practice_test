﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Database;
using System.Data;

namespace WebApplication1 {
    public partial class Authors : System.Web.UI.Page {
        // Прорисовка всех элементов формы
        public void Refresh(AuthorsDB authors) {
            int pos = authors.pos;
            BooksDB books = BooksDB.Create(Session);
            for (int i=0;i<3;i++) {
                switch (i) {
                    case 0: this.LabelN1.Text = ""+(pos+1); break;
                    case 1: this.LabelN2.Text = ""+(pos+2); break;
                    case 2: this.LabelN3.Text = ""+(pos+3); break;
                }
                if (pos+i < authors.dt.Rows.Count) {
                    DataRow dr = authors.dt.Rows[pos+i];
                    String fio = (String)dr["FIO"];
                    int id = (int)dr["ID"];
                    switch (i) {
                        case 0: this.LabelAuthor1.Text = fio; this.LabelBook1.Text = ""+books.getByAutor(id).Length; break;
                        case 1: this.LabelAuthor2.Text = fio; this.LabelBook2.Text = ""+books.getByAutor(id).Length; break;
                        case 2: this.LabelAuthor3.Text = fio; this.LabelBook3.Text = ""+books.getByAutor(id).Length; break;
                    }
                }
                else {
                    switch (i) {
                        case 0: this.LabelAuthor1.Text = this.LabelBook1.Text = "-"; break;
                        case 1: this.LabelAuthor2.Text = this.LabelBook2.Text = "-"; break;
                        case 2: this.LabelAuthor3.Text = this.LabelBook3.Text = "-"; break;
                    }
                }
            }
        }

        // Загрузка формы
        protected void Page_Load(object sender, EventArgs e) {
            if(!Page.IsPostBack) {
                AuthorsDB authors = AuthorsDB.Create(Session);
                Refresh(authors);
            }
        }

        // Событие на нажатие на кнопку назад
        protected void ButtonPrev_Click(object sender, EventArgs e) {
            AuthorsDB authors = AuthorsDB.Create(Session);
            int pos = authors.pos;
            if (pos - 3 >= 0) pos -= 3; else pos = 0;
            authors.setPos(Session,pos);
            Refresh(authors);
        }

        // Событие на нажатие на кнопку вперед
        protected void ButtonNext_Click(object sender, EventArgs e) {
            AuthorsDB authors = AuthorsDB.Create(Session);
            int pos = authors.pos;
            if (pos + 3 < authors.dt.Rows.Count) pos += 3;
            authors.setPos(Session,pos);
            Refresh(authors);
        }

        // Событие на удаление автора
        protected void ButtonDel1_Click(object sender, EventArgs e) {
            int i;
            if (sender == ButtonDel1) {
                i = 0;
            }
            else if (sender == ButtonDel2) {
                i = 1;
            }
            else {
                i = 2;
            }
            AuthorsDB authors = AuthorsDB.Create(Session);
            if (authors.pos+i < authors.dt.Rows.Count) {
                BooksDB books = BooksDB.Create(Session);
                DataRow dr = authors.dt.Rows[authors.pos+i];                
                if (books.getByAutor((int)dr["ID"]).Length == 0) { 
                    dr.Delete();
                    authors.ad.Update(authors.dt);
                    Refresh(authors);
                }
                else {
                    throw new Exception("Есть книги данного автора");
                }
            }
        }

        // Событие на редактирование автора
        protected void ButtonEdit1_Click(object sender, EventArgs e) {
            AuthorsDB authors = AuthorsDB.Create(Session);
            int i;
            if (sender == ButtonEdit1) {
                i = 0;
            }
            else if (sender == ButtonEdit2) {
                i = 1;
            }
            else {
                i = 2;
            }
            if (authors.pos+i < authors.dt.Rows.Count) {
                Response.Redirect("~/AuthorsParam?id="+(int)authors.dt.Rows[authors.pos+i]["ID"]);
            }
        }

        // Событие на отображение всех книг автора
        protected void ButtonAll1_Click(object sender, EventArgs e) {
            AuthorsDB authors = AuthorsDB.Create(Session);
            int i;
            if (sender == ButtonAll1) {
                i = 0;
            }
            else if (sender == ButtonAll2) {
                i = 1;
            }
            else {
                i = 2;
            }
            if (authors.pos+i < authors.dt.Rows.Count) {
                Response.Redirect("~/Books?id_author="+(int)authors.dt.Rows[authors.pos+i]["ID"]);
            }
        }

        // Переход на главную форму
        protected void ButtonMain_Click(object sender, EventArgs e) {
            Response.Redirect("~/Default");
        }

        // Обновление
        protected void ButtonRefresh_Click(object sender, EventArgs e) {
            Refresh(AuthorsDB.Create(Session));
        }
    }
}