﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Database;
using System.Data;

namespace WebApplication1 {
    public partial class Genres : System.Web.UI.Page {
        public void Refresh(GenresDB genres) {
            int pos = genres.pos;
            BooksDB books = BooksDB.Create(Session);
            for (int i=0;i<3;i++) {
                switch (i) {
                    case 0: this.LabelN1.Text = ""+(pos+1); break;
                    case 1: this.LabelN2.Text = ""+(pos+2); break;
                    case 2: this.LabelN3.Text = ""+(pos+3); break;
                }
                if (pos+i < genres.dt.Rows.Count) {
                    DataRow dr = genres.dt.Rows[pos+i];
                    String ge = (String)dr["Genre"];
                    int id = (int)dr["ID"];
                    switch (i) {
                        case 0: this.LabelGenres1.Text = ge; this.LabelBook1.Text = ""+books.getByGenre(id).Length; break;
                        case 1: this.LabelGenres2.Text = ge; this.LabelBook2.Text = ""+books.getByGenre(id).Length; break;
                        case 2: this.LabelGenres3.Text = ge; this.LabelBook3.Text = ""+books.getByGenre(id).Length; break;
                    }
                }
                else {
                    switch (i) {
                        case 0: this.LabelGenres1.Text = this.LabelBook1.Text = "-"; break;
                        case 1: this.LabelGenres2.Text = this.LabelBook2.Text = "-"; break;
                        case 2: this.LabelGenres3.Text = this.LabelBook3.Text = "-"; break;
                    }
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e) {
            if(!Page.IsPostBack) {
                GenresDB genres = GenresDB.Create(Session);
                Refresh(genres);
            }

        }
        protected void ButtonPrev_Click(object sender, EventArgs e) {
            GenresDB genres = GenresDB.Create(Session);
            int pos = genres.pos;
            if (pos - 3 >= 0) pos -= 3; else pos = 0;
            genres.setPos(Session,pos);
            Refresh(genres);
        }

        protected void ButtonNext_Click(object sender, EventArgs e) {
            GenresDB genres = GenresDB.Create(Session);
            int pos = genres.pos;
            if (pos + 3 < genres.dt.Rows.Count) pos += 3;
            genres.setPos(Session,pos);
            Refresh(genres);
        }

        protected void ButtonDel1_Click(object sender, EventArgs e) {
            int i;
            if (sender == ButtonDel1) {
                i = 0;
            }
            else if (sender == ButtonDel2) {
                i = 1;
            }
            else {
                i = 2;
            }
            GenresDB genres = GenresDB.Create(Session);
            if (genres.pos+i < genres.dt.Rows.Count) {
                BooksDB books = BooksDB.Create(Session);
                DataRow dr = genres.dt.Rows[genres.pos+i];
                if (books.getByGenre((int)dr["ID"]).Length == 0) {
                    dr.Delete();
                    genres.ad.Update(genres.dt);
                    Refresh(genres);
                }
                else {
                    throw new Exception("Есть книги данного жанра");
                }
            }
        }

        protected void ButtonEdit1_Click(object sender, EventArgs e) {
            GenresDB genres = GenresDB.Create(Session);
            int i;
            if (sender == ButtonEdit1) {
                i = 0;
            }
            else if (sender == ButtonEdit2) {
                i = 1;
            }
            else {
                i = 2;
            }
            if (genres.pos+i < genres.dt.Rows.Count) {
                Response.Redirect("~/GenresParam?id="+(int)genres.dt.Rows[genres.pos+i]["ID"]);
            }
        }

        protected void ButtonMain_Click(object sender, EventArgs e) {
            Response.Redirect("~/Default");
        }

        protected void ButtonRefresh_Click(object sender, EventArgs e) {
            Refresh(GenresDB.Create(Session));
        }
   }
}