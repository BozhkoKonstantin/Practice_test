﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Database;
using System.Data;

namespace WebApplication1 {
    public partial class GenresParam : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {
            if(!Page.IsPostBack) {
                id.Value = Request["id"];
                if (id.Value != "") {
                    GenresDB genres = GenresDB.Create(Session);
                    textBoxGenres.Text = (String)genres.dt.Select("ID="+id.Value)[0]["Genre"];
                    ButtonNew.Text = "Изменить";
                }
                else {
                    ButtonNew.Text = "Добавить";
                }
            }
        }

        protected void ButtonNew_Click(object sender, EventArgs e) {
            if (!Page.IsValid) {
                throw new Exception("Параметры не введены!");
            }

            GenresDB genres = GenresDB.Create(Session);
            DataRow dr;
            id.Value = Request["id"];
            if (id.Value == "") {                
                dr = genres.dt.NewRow();
                dr["Genre"] = textBoxGenres.Text;
                genres.dt.Rows.Add(dr);
                genres.ad.Update(genres.dt);
                Response.Write("<script>self.close();</script>");
            }
            else {
                dr = genres.dt.Select("ID="+id.Value)[0];
                dr["Genre"] = textBoxGenres.Text;
                genres.ad.Update(genres.dt);
                Response.Redirect("~/Genres");
            }
        }
    }
}