﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Database;
using System.Data;

namespace WebApplication1 {
    public partial class BooksParam : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {
            if (!Page.IsPostBack) {
                BooksDB books = BooksDB.Create(Session);
                AuthorsDB authors = AuthorsDB.Create(Session);
                GenresDB genres = GenresDB.Create(Session);
                DataRow dr_sel = null;

                id.Value = Request["id"];
                id_author.Value = Request["id_author"];
                if (id.Value != "") {
                    dr_sel = books.dt.Select("ID="+id.Value)[0];
                }
                int i = 0;
                foreach (DataRow dr in authors.dt.Rows) {
                    ListBoxAuthor.Items.Add((String)dr["FIO"]);
                    if ((dr_sel != null) && ((int)(dr_sel["ID_Author"]) == (int)dr["ID"])) ListBoxAuthor.SelectedIndex =  i;
                    i++;
                }     
                i = 0;
                foreach (DataRow dr in genres.dt.Rows) {
                    ListBoxGenre.Items.Add((String)dr["Genre"]);
                    if ((dr_sel != null) && ((int)(dr_sel["ID_Genre"]) == (int)dr["ID"])) ListBoxGenre.SelectedIndex =  i;
                    i++;
                }     
                if (dr_sel != null) {
                    textBoxBook.Text = (String)dr_sel["Book"];
                    ButtonNew.Text = "Изменить";
                }
                else {
                    ListBoxAuthor.SelectedIndex = 0;
                    ListBoxGenre.SelectedIndex = 0;
                    ButtonNew.Text = "Добавить";
                }
            }
        }

        protected void ButtonNew_Click(object sender, EventArgs e) {
            if (!Page.IsValid) {
                throw new Exception("Параметры не введены!");
            }

            BooksDB books = BooksDB.Create(Session);
            AuthorsDB authors = AuthorsDB.Create(Session);
            GenresDB genres = GenresDB.Create(Session);
            DataRow dr;

            id.Value = Request["id"];
            if (id.Value == "") {
                dr = books.dt.NewRow();
                dr["Book"] = textBoxBook.Text;
                dr["ID_Genre"] = (int)genres.dt.Rows[ListBoxGenre.SelectedIndex]["ID"];
                dr["ID_Author"] = (int)authors.dt.Rows[ListBoxAuthor.SelectedIndex]["ID"];
                books.dt.Rows.Add(dr);
                books.ad.Update(books.dt);
                Response.Write("<script>self.close();</script>");
            }
            else {
                dr = books.dt.Select("ID="+id.Value)[0];
                dr["Book"] = textBoxBook.Text;
                dr["ID_Genre"] = (int)genres.dt.Rows[ListBoxGenre.SelectedIndex]["ID"];
                dr["ID_Author"] = (int)authors.dt.Rows[ListBoxAuthor.SelectedIndex]["ID"];
                books.ad.Update(books.dt);
                if (id_author.Value != "") {
                    Response.Redirect("~/Books?id_author="+id_author.Value);
                }
                else {
                    Response.Redirect("~/Books");
                }
            }
        }
    }
}