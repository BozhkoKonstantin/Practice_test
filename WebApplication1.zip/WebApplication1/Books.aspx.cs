﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Database;
using System.Data;

namespace WebApplication1 {
    public partial class Books : System.Web.UI.Page {
        public DataRow[] getDrr(BooksDB books) {
            if (id_author.Value != "") {
                return books.dt.Select("ID_Author="+id_author.Value);
            }
            else {
                return books.dt.Select();
            }
        }

        public void Refresh(BooksDB books) {
            int pos = books.pos;
            AuthorsDB authors = AuthorsDB.Create(Session);
            GenresDB genres = GenresDB.Create(Session);

            id_author.Value = Request["id_author"];
            DataRow[] drr = getDrr(books);

            for (int i=0;i<3;i++) {
                switch (i) {
                    case 0: this.LabelN1.Text = ""+(pos+1); break;
                    case 1: this.LabelN2.Text = ""+(pos+2); break;
                    case 2: this.LabelN3.Text = ""+(pos+3); break;
                }
                if (pos+i < drr.Length) {
                    DataRow dr = drr[pos+i];
                    String book = (String)dr["Book"];
                    int id_author = (int)dr["ID_Author"];
                    int id_genre = (int)dr["ID_Genre"];
                    switch (i) {
                        case 0: this.LabelBook1.Text = book; this.LabelAuthor1.Text = authors.get(id_author); this.LabelGenre1.Text = genres.get(id_genre); break;
                        case 1: this.LabelBook2.Text = book; this.LabelAuthor2.Text = authors.get(id_author); this.LabelGenre2.Text = genres.get(id_genre); break;
                        case 2: this.LabelBook3.Text = book; this.LabelAuthor3.Text = authors.get(id_author); this.LabelGenre3.Text = genres.get(id_genre); break;
                    }
                }
                else {
                    switch (i) {
                        case 0: this.LabelAuthor1.Text = this.LabelBook1.Text = this.LabelGenre1.Text = "-"; break;
                        case 1: this.LabelAuthor2.Text = this.LabelBook2.Text = this.LabelGenre2.Text = "-"; break;
                        case 2: this.LabelAuthor3.Text = this.LabelBook3.Text = this.LabelGenre3.Text = "-"; break;
                    }
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e) {
            if (!Page.IsPostBack) {
                BooksDB books = BooksDB.Create(Session);
                Refresh(books);
            }
        }
        protected void ButtonPrev_Click(object sender, EventArgs e) {
            BooksDB books = BooksDB.Create(Session);
            int pos = books.pos;
            if (pos - 3 >= 0) pos -= 3; else pos = 0;
            books.setPos(Session,pos);
            Refresh(books);
        }

        protected void ButtonNext_Click(object sender, EventArgs e) {
            BooksDB books = BooksDB.Create(Session);
            int pos = books.pos;
            if (pos + 3 < getDrr(books).Length) pos += 3;
            books.setPos(Session,pos);
            Refresh(books);
        }

        protected void ButtonDel1_Click(object sender, EventArgs e) {
            int i;
            if (sender == ButtonDel1) {
                i = 0;
            }
            else if (sender == ButtonDel2) {
                i = 1;
            }
            else {
                i = 2;
            }
            BooksDB books = BooksDB.Create(Session);
            DataRow[] drr = getDrr(books);
            if (books.pos+i < drr.Length) {
                DataRow dr = drr[books.pos+i];                
                dr.Delete();
                books.ad.Update(books.dt);
                Refresh(books);
            }
        }

        protected void ButtonEdit1_Click(object sender, EventArgs e) {
            BooksDB books = BooksDB.Create(Session);
            String param = "";            

            int i;
            if (sender == ButtonEdit1) {
                i = 0;
            }
            else if (sender == ButtonEdit2) {
                i = 1;
            }
            else {
                i = 2;
            }
            DataRow[] drr = getDrr(books);
            if (books.pos+i < drr.Length) {
                param = "id="+(int)drr[books.pos+i]["ID"];
            }
            if (id_author.Value != "") {
                if (param.Length > 0) param += "&";
                param += "id_author="+id_author.Value;
            }
            if (param.Length > 0) {
                param = "?"+param;
            }
            Response.Redirect("~/BooksParam"+param);
        }

        protected void ButtonMain_Click(object sender, EventArgs e) {
            Response.Redirect("~/Default");
        }

        protected void ButtonRefresh_Click(object sender, EventArgs e) {
            Refresh(BooksDB.Create(Session));
        }
   }
}