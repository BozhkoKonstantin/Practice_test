﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OleDb;
using System.Web.SessionState;

namespace WebApplication1.Database {
    public class BooksDB {
        public OleDbDataAdapter ad;
        OleDbCommandBuilder bs;
        public DataTable dt = new DataTable();
        public int pos = 0;

        public static BooksDB Create(HttpSessionState app) {
            int pos;
            if (app["booksDB"] != null) {
                pos = (int)app["booksDB"];
            }
            else {
                app["booksDB"] = pos = 0;
            }
            return new BooksDB(pos);
        }

        public BooksDB(int pos) {
            ad = new OleDbDataAdapter("SELECT * FROM Books ORDER BY ID", Global.dbConnection);
            ad.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            ad.Fill(dt);
            bs = new OleDbCommandBuilder(ad);
            bs.GetUpdateCommand();
            bs.GetInsertCommand();
            bs.GetDeleteCommand();
            this.pos = pos;
        }

        public void setPos(HttpSessionState app, int pos) {
            app["booksDB"] = this.pos = pos;
        }

        public DataRow[] getByAutor(int id) {
            return dt.Select("ID_Author="+id);
        }

        public DataRow[] getByGenre(int id) {
            return dt.Select("ID_Genre="+id);
        }
    }
}